#include<Rcpp.h>
#include<iostream>
#include<vector>
#include"EuropeanOption.h"
#include<ctime>
#include<cstdlib>
#include"functions.h"

using std::vector;
using std::cin;
using namespace Rcpp;

//[[Rcpp::export]]
double getEuropeanCallPrice(
    int nInt,
    double strike,
    double spot,
    double vol,
    double r,
    double expiry,
    double barrier,
    int nReps
){
  
  // set the seed
  srand( time(NULL) );
  
  //create a new instance of class
  EuropeanOption myEuropean(nInt, strike, spot,
                      vol, r, expiry, barrier);
  return myEuropean.getEuropeanCallPrice(nReps);
}
