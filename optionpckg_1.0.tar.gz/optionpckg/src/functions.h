//
//
//

//functions prototypes
double mean (std::vector<double> thisVec);
double stdDev (std::vector<double> thisVec);
