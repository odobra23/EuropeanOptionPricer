#include"EuropeanOption.h"
#include<cmath>
#include<iostream>
#include"Random1.h"


//definition of constructor
EuropeanOption::EuropeanOption(
	int nInt_,
	double strike_,
	double spot_,
	double vol_,
	double r_,
	double expiry_,
	double barrier_){
		nInt = nInt_;
		strike = strike_;
		spot = spot_;
		vol = vol_;
		r = r_;
		expiry = expiry_;
		barrier = barrier_;
		generatePath();
}

//method definition
void EuropeanOption::generatePath(){
	double thisDrift = (r * expiry - 0.5 * vol * vol * expiry) / double(nInt);
	double cumShocks = 0;
	thisPath.clear();

	for(int i = 0; i < nInt; i++){
		cumShocks += (thisDrift + vol * sqrt(expiry / double(nInt)) * GetOneGaussianByBoxMuller());
		thisPath.push_back(spot * exp(cumShocks));
	}
}

//method definition
double EuropeanOption::getArithmeticMean(){

	double runningSum = 0.0;

	for(int i = 0; i < nInt; i++){
		runningSum += thisPath[i];
	}

	return runningSum / double(nInt);
}


//method definition
void EuropeanOption::printPath(){

	for(int i = 0; i < nInt; i++){

		std::cout << thisPath[i] << "\n";

	}
}

//We must check if the barrier level is reached at any point on the path
bool EuropeanOption::if_reaches_barrier(){
  for (int i=0; i<thisPath.size(); i++){
    if (thisPath[i] <= barrier) 
      return true;}
}

//Also take last price generated
double EuropeanOption::last_opt_price(){
  return thisPath[thisPath.size()-1];
}

//method definition
double EuropeanOption::getEuropeanCallPrice(int nReps){
  
// we start with rolling sum of 0
	double rollingSum = 0.0;
	double thisMean   = 0.0;

	for(int i = 0; i < nReps; i++){
		generatePath();
	  double payoff = 0.0;
	
    // counting payoffs if barrier was reached
		payoff = std::max(last_opt_price() - strike, 0.0);
		
		// if barrier was not reached payoff is equal to zero
		if (if_reaches_barrier() == false) payoff = 0.0;
		  rollingSum += payoff;
	}

// last element is average profit and exp is a discont value
	return exp(-r * expiry) * rollingSum / double(nReps); 

}


//overloaded operator ();
double EuropeanOption::operator()(char char1, char char2, int nReps){
	     if ((char1 == 'A') & (char2 =='C')) return getEuropeanCallPrice(nReps);
	else return -99;
}
