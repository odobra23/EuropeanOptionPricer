#include<iostream>
#include<vector>
#include"EuropeanOption.h"
#include<ctime>
#include<cstdlib>
#include"functions.h"

using std::vector;
using std::cout;
using std::cin;

int main(){

	// set the seed
	srand( time(NULL) );

    // cout << "arithmetic mean = " ;

	//create a new instance of class - I assume my barrier to be 91
	EuropeanOption myEuropean(126, 100, 95, 0.2, 0.06, 0.5, 91);

	// Iterate over all the elements.
	// myEuropean.printPath();

 // print barrier value
	cout << "barrier = " << myEuropean.barrier << "\n";

	//get arithmetic means
	cout << "arithmetic mean = " << myEuropean.getArithmeticMean() <<"\n";

	//get last price of underlying - back returns the last vector's element
	cout << "Last price of underlying = " << myEuropean.thisPath.back() << "\n";

	//run Monte Carlo to obtain theoretical price of arithmetic asian call - 10 000 iterations
	cout << "Price of European down-and-in Call = " << myEuropean.getEuropeanCallPrice(10000) << "\n";

	//call Monte Carlo via overloaded () operator
	cout << "calling functions via operator() \n";
	cout << "Price of European down-and-in Call = " <<  myEuropean('A', 'C', 10000) << "\n";

	//check whether data generating process runs correctly
	//(is the expected price and volatility of underlying close to option parameters?)
	vector<double> myVec2;
	for(int i = 0; i < 1000; i++){
	  myEuropean.generatePath();
		myVec2.push_back(myEuropean.thisPath.back());
	}

	cout << "mean of last underlying prices is " << mean(myVec2) << "\n";
	cout << "stddev of last underlying prices is " << stdDev(myVec2) << "\n";



	//cout << "\nPress Enter to continue...";
	//cin.get();
	return 0;
}
